<?php
session_start();
error_reporting(0);

//if (isset($_SESSION["manager"])) {
//	header("location: adminhome.php");
//	exit();
//}
?>

<html>
  <head>
  <title>Admin Control Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="admin_login_new.css">
  </head>
<body>
  <div class = "container">
   <?php include_once("admin_login_form.php");?>  

<?php

   // Connect to the database
       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');

    // Grab the user login data

     if (isset($_POST['usr']) && isset($_POST['pass'])) {
      $username = trim($_POST['usr']);
      $password = trim($_POST['pass']);
    }
      //$username = trim($_POST['usr']);
      //$password = trim($_POST['pass']);

     if (!empty($username) && !empty($password)) {
        // Look up the username and password in the database
        $query = "SELECT username FROM admins WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
           // Confirm the successful log-in
    	
    	$_SESSION['manager'] = $username;
 //   	setcookie('manager', $row['manager'], time() + (60 * 60 * 24 * 30));  // expires in 30 days
		echo ('<h3>Login Successful</h3>
          <a class="btn btn-lg btn-primary btn-block" href="adminhome.php">Admin Control Panel</a>');
        }
        else {
          // The username/password are incorrect so set an error message
          	echo('<div class="sorry"><p> sorry, you must enter a valid username and password to log in.</p></div>');
			echo('<a class="btn btn-lg btn-primary btn-block btn-warning" href="adminforgetpass.php" type="submit">Forgot Password.</a>');
			echo('<a class="btn btn-lg btn-primary btn-block" href="adminnewaccount.php">Create New Account.</a>');
        	}
		}    

?>

</div>
</body></html>