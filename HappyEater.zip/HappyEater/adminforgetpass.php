<?php
session_start();
?>

<?php
error_reporting(0);
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<html>
<head>
<title>Password Reset Page</title>
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="adminforgetpass.css">
</head>

<body>

  <div class = "container">
  <form method="post" action="adminforgetpass1.php" class="form-signin" >

<h2 class="form-signin-heading">Reset password</h2>
<hr />

<div class="enter">
  <label for="inputUsername" class="sr-only">Username</label>
  <input type="username" name="user" id="inputUsername" class="form-control" placeholder="admin username" required>
</div>

 <button class="btn btn-lg btn-primary btn-block" type="submit">Reset</button>

</form>

</div>
</body></html>      
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
      
      	