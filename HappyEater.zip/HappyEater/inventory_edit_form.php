<form action="Inventory_edit.php" enctype="multipart/form-data" method="post">

<div class="enter">Menu Item Title
  <label><input  name="ItemTitle" type="text"value="<?php echo $itemTitle; ?>"id="ItemTitle" </label>
</div>

<div class="enter">Menu Item Description
  <label><input  name="ItemDesc" type="text" value="<?php echo $itemDesc; ?>"id="ItemDesc"</label>
</div>

<div class="enter">Menu Item Price
  <label><input  name="Price" type="text" value="<?php echo $price; ?>"id="Price"</label>
</div>

<div class="enter">Menu Item Category
  <label><input  name="category" type="text" value="<?php echo $category; ?>"id="category"</label>
</div>

<div class="enter">Product Image
  <label><input  name="fileField" type="file" value="<?php echo $category; ?>"id="fileField"</label>
</div>

<div class="enter">
  <input  name="thiID" type="hidden" value="<?php echo $iid; ?>"/>
</div>

<div class="enter">
  <input  name="thiID" type="submit" value="Update Item"/>
</div>

</form>


