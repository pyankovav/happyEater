<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-6 social">
                <h4>Stay Connected</h4>
                <a href="#">
                    <i class="fa fa-twitter-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-facebook-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-pinterest-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-instagram"></i>
                </a>
            </div>
            <div class="col-md-6">
                <div class="pull-right">
                    <h4>Need assistance?</h4>
                    <b>call</b>: 212 345 6789
                    <br>
                    <a href="mailto:support@happyeater.com">
                        email us
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="sub-footer text-center">
    &copy; 2015 Happy <a href="admin_login_new.php"><i class="fa fa-smile-o"></i></a> Eater
</div>

<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/latest/js/bootstrap.min.js"></script>

