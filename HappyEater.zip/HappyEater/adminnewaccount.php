<?php
session_start();
error_reporting(0);
if (isset($_SESSION["manager"])) {
  header("location: adminhome.php");
  exit();
}
?>

<?php
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<html>
<head>
<title>New Admin Account</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="adminnewaccount.css">
</head>

<body>
<div class = "container">
  <form method="post" action="adminnewaccount.php" class="form-signin" >
<h2 class="form-signin-heading">Create Your Administrative Account</h2>

<div class="enter">
  <label for="inputUsername" class="sr-only">Username</label>
  <input type="username" name="usr" id="usr" class="form-control" placeholder="admin username" required>
</div>
<div class="enter">
  <label for="pass" class="sr-only">Password</label>
  <input type="password" name="pass" id="pass" class="form-control" placeholder="admin password" required>
</div>
 <button class="btn btn-lg btn-primary btn-block" type="submit">Create Admin Account</button>
</form>

<?php
 	// Connect to the database
       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');

    if (isset($_POST['usr']) && isset($_POST['pass'])) {
      $username = trim($_POST['usr']);
      $password = trim($_POST['pass']);
    }    		
      		
			if (!empty($username) && !empty($password)) {
        	//Store username and password in the database
       		$query = "INSERT INTO admins VALUES ('$username' , '$password')";       		
       		$result = mysqli_query($con, $query);
       		
		//	echo('<h3> Dear <span class="word"> ' . $username. '</span> . Your Administrative Account has been successfully created</h3>');  
       
       		$query1 = "SELECT username FROM admins WHERE username = '$username' AND Password = '$password'";
        	$result1 = mysqli_query($con, $query1);
         		if (mysqli_num_rows($result1) == 1) {
             
        		  echo('<h3>Login Successful</h3><h3>You are logged in as <span class="word"> ' . $username . '</span>.</h3>
                   <a href="adminhome.php" class="btn btn-lg btn-primary btn-block" role="button">Admin Control Panel</a>');
           		
           		}	else {
               		echo('<div class="sorry"> Sorry, you must enter a valid username and password to create account.</div>');
               		}
         		}    
       		
?>
</body>
</html>