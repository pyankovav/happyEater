<?php
session_start();

error_reporting(0);

if (isset($_SESSION["username"])) {
 header("location:index_customer.php");
 exit();
 } 
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Order Online</title>

<!--
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"> -->

<meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" type="text/css" href="custom.css">
    <link rel="stylesheet" type="text/css" href="OrderOnline.css">
</head>

<body>
<!-- header goes here-->

<!--<?php //include_once("template_header.php");?>-->

<?php include_once("header_orderonline.php");?>
<div class="container container-orderonline"> 
  <div class="row">

  <!--Login Form-->
   <div class="col-sm-6"> 
      <?php include_once("customer_login_form.php");?>
  </div>

  <div class="col-sm-6">
  <?php
         // Connect to the database
           $con = mysqli_connect ('localhost', 'root', '', 'Orders')
            or die('Error connecting to MySQL server.');

            // Grab the user login data
            $username = trim($_POST['usr']);
            $password = trim($_POST['pass']);  

           if (!empty($username) && !empty($password)) {
              // Look up the username and password in the database
              $query = "SELECT username FROM CustInfo WHERE username = '$username' AND password = '$password'";
              $result = mysqli_query($con, $query);

              if (mysqli_num_rows($result) == 1) {      

                 // Confirm the successful log-in
          
            $_SESSION['usr'] = $username;
            setcookie('usr', $row['usr'], time() + (60 * 60 * 24 * 30));  // expires in 30 days
              header ('location:index_customer.php');
          
              }
                       
      }

       else {

                   

        // The username/password weren't entered so set an error message
        //echo('<div class="sorry">Create new account</div>');

        echo('<div class="sorry"><h2> Create new account</h2></div>');
      echo('<form method="post" action="newaccount.php">');
    //  echo('<p> Create Username: <input type="text" name="usr" placeholder="username"> ');
    echo(' <div class="create_new">
      <label for="usr" >Username</label>
      <input type="text" name="usr"  class="form-control" placeholder="create username" required>
      </div>');

     //   echo('<p> Create Password:<input type="password" name="pass" placeholder="password"></p><p>');
    echo(' <div class="create_new">
          <label for="inputPassword" >Password</label>
          <input type="text" name="pass"  class="form-control" placeholder="create password" required>
        </div>');


     //   echo('<p> First Name:<input type="text" name="fname" placeholder="First Name"></p><p>');
    echo(' <div class="create_new">
          <label for="FirstName" >First Name</label>
          <input type="text" name="Fname"  class="form-control" placeholder="first name" required>
        </div>');


     //   echo('<p> Last Name:<input type="text" name="Lname" placeholder="Last Name"></p><p>');
    echo(' <div class="create_new">
          <label for="LastName" >Last Name</label>
          <input type="text" name="Lname"  class="form-control" placeholder="last name" required>
        </div>');


    //    echo('<p> Email:<input type="text" name="email" placeholder="Email"></p><p>');
    echo(' <div class="create_new">
          <label for="email" >email</label>
          <input type="email" name="email"  class="form-control" placeholder="email" required>
        </div>');


     //   echo('<p> Address:<input type="text" name="addess" placeholder="Address"></p><p>');
    echo(' <div class="create_new">
          <label for="address" >Address</label>
          <input type="text" name="address"  class="form-control" placeholder="address" required>
        </div>');


     //   echo('<p> Zip:<input type="text" name="zip" placeholder="Zip code"></p><p>');
    echo(' <div class="create_new">
          <label for="zip" >Zip</label>
          <input type="text" name="zip"  class="form-control" placeholder="zip" required>
        </div>');


     //   echo('<p> Phone:<input type="text" name="phone" placeholder="Phone"></p><p>');
    echo(' <div class="create_new">
          <label for="phone" >Phone</label>
          <input type="text" name="phone"  class="form-control" placeholder="phone" required>
        </div>');


    //    echo('<p> Comments:<input type="textarea" name="comments" placeholder="Special Instructions"></p><p>');
    echo(' <div class="create_new">
          <label for="comments">Comments</label>
          <textarea class="form-control" rows="5" name="comment" id="comment" placeholder="your comments"></textarea>
        </div>'); 


    //  echo('<input type="submit" value="Create Account"></p></form>');
      echo('<button class="btn btn-lg btn-primary btn-block" type="submit">Create Account</button>');
      }
     ?>
    </div>

</div>
</div>      

<?php include_once("footer_customer.php");?>
</body>
</html>
