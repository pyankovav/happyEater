
<?php
session_start();
if (isset($_SESSION["username"])) {
    header("location: index_customer.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Happy Eater | Home page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">

</head>
<body>
<header class="clearfix">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Happy <i class="fa fa-smile-o"></i> Eater</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php ">Sign out</a></li>
                    <!--<li><a href="OrderOnline.php">Register</a></li>-->
                    <li><a href="Cart.php"><i class="fa fa-shopping-bag"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<div class="main">
    <div class="container">
        <div class="row menu-sections">
            <div class="col-md-6 text-center">
                <div class="row">
                    <div class="col-sm-6">
                        <a href="/OrderSelection.php#breakfast">
                            <div class="hover-zoom breakfest">
                                <img class="img-responsive" alt="" src="assets/img/breakfast.jpg">
                            </div>
                            <h4>Breakfast</a></h4>
                        </a>
                    </div>
                    <div class="col-sm-6">
                        <a href="/OrderSelection.php#lunch">
                            <div class="hover-zoom lunch">
                                <img class="img-responsive" alt="" src="assets/img/breakfast.jpg">
                            </div>
                            <h4>Lunch</h4>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="row">
                    <div class="col-sm-6">
                        <a href="/OrderSelection.php#dinner">
                            <div class="hover-zoom dinner">
                                <img class="img-responsive" alt="" src="assets/img/breakfast.jpg">
                            </div>
                            <h4>Dinner</h4>
                        </a>
                    </div>
                    <div class="col-sm-6">
                        <a href="/OrderSelection.php#allday">
                            <div class="hover-zoom all-day">
                                <img class="img-responsive" alt="" src="assets/img/breakfast.jpg">
                            </div>
                            <h4>All Day</h4>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-6 social">
                <h4>Stay Connected</h4>
                <a href="#">
                    <i class="fa fa-twitter-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-facebook-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-pinterest-square"></i>
                </a>
                <a href="#">
                    <i class="fa fa-instagram"></i>
                </a>
            </div>
            <div class="col-md-6">
                <div class="pull-right">
                    <h4>Need assistance?</h4>
                    <b>call</b>: 212 345 6789
                    <br>
                    <a href="mailto:support@happyeater.com">
                        email us
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="sub-footer text-center">
    &copy; 2015 Happy<i class="fa fa-smile-o"></i></a> Eater
</div>

<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/latest/js/bootstrap.min.js"></script>

</body>
</html>