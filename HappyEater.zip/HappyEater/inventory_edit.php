<?php
session_start();
//if (!isset($_SESSION["manager"])) {
//	header("location: admin_login_new.php");
//	exit();
//	}
error_reporting(0);

?>
<html>
<head>
<title>Edit Inventory</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" type="text/css" href="updateinventory.css">
    <link rel="stylesheet" type="text/css" href="custom.css">
</head>
<body>
<div class="container">
<h1>Edit menu item</h1>
<hr />
<?php
//Display chosen menu item
if(isset($_GET['itemid'])) {

	$con = mysqli_connect ('localhost', 'root', '', 'Orders')
	or die('Error connecting to MySQL server.');
	$itemid = $_GET['itemid'];

	$sql= "SELECT * FROM Menu where ItemID = '$itemid' LIMIT 1";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) == 1) {

		$row = mysqli_fetch_array($result);
       	$itemTitle = $row["ItemTitle"];
      	$itemDesc = $row["ItemDesc"];
     	$price = $row["Price"];
     	$category = $row["category"];
		} else {
		echo ('No products to display');
  		}
	
	}
?>

<form action="Inventory_edit.php" enctype="multipart/form-data" method="post">

<div class="form-group">
  <label for="ItemTitle">Menu Item Title</label>
  <input  name="ItemTitle" type="text" class="form-control" value="<?php echo $itemTitle; ?>" id="ItemTitle"/> 
</div>

<div class="form-group">
  <label for="ItemID">Menu Item ID</label>
  <input  name="ItemID" type="text" class="form-control" value="<?php echo $itemid; ?>" id="ItemID"/> 
</div>

<div class="form-group">
	<label for="ItemDesc">Menu Item Description</label>
  <input name="ItemDesc" type="text" class="form-control" value="<?php echo $itemDesc; ?>" id="ItemDesc"></input>
</div>

<div class="form-group">
  <label for="Price">Menu Item Price</label>
  	<div class="input-group">
	  <span class="input-group-addon" id="basic-addon1">$</span>
	  <input  name="Price" type="text" class="form-control" value="<?php echo $price; ?>" id="Price"/> 
	</div>  
</div>

<div class="form-group">
  <label for="category">Menu Item Category</label>
  <input  name="category" type="text" class="form-control" value="<?php echo $category; ?>" id="category"/> 
</div>

<div class="form-group">
  <label for="fileField">Product Image</label>
  <input  name="fileField" type="file" id="fileField"/>
</div>

<div class="form-group">
	<input type="hidden" name="thisID" value="<?php echo $itemid; ?>" />
	<input class="btn btn-lg btn-primary btn-block" type="submit" value="Update Item" /></button>
</div>

<!--<tr><td><input type="hidden" name="thisID" value="<//?php echo $itemid; ?>" />
<input type="submit" value="Update Item" />
	</td></tr>-->
</form>


<?php  
if (isset($_POST['ItemTitle'])) {
	
	$itemid = trim($_POST['thisID']);
	$title = trim($_POST['ItemTitle']);
	$desc = trim($_POST['ItemDesc']);
	$price = trim($_POST['Price']);
	$cat = trim($_POST['category']);
	
	$con = mysqli_connect ('localhost', 'root', '', 'Orders');
	//Update this menu item in the Menu table
	$sql = "UPDATE Menu SET ItemTitle='$title', ItemDesc='$desc', Price='$price', category='$cat' WHERE ItemId='$itemid' ";
	$result = mysqli_query($con, $sql);
	//$pid = mysqli_insert_id($con);
	//Place image in the folder	
	$newname = "$itemid.jpg";
			move_uploaded_file( $_FILES['fileField']['tmp_name'], "images/$newname");
			header("location: UpdateInventory.php");
			exit();
			}
?>
<!--<form action="UpdateInventory.php" enctype="multipart/form-data" method="get">
<input type="submit" value="Back to Manage Inventory" />
</form>-->
</div>
</body></html>