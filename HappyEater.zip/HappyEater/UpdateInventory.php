<?php
session_start();
if (!isset($_SESSION["manager"])) {
	header("location: admin_login_new.php");
	exit();
}
?>
<?php
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<html>
<head>
<title>Admin Control Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="UpdateInventory.css" / >
</head>
<body>
<div class="sure">
<?php
//Delete Item

if(isset($_GET['deleteid'])) {
	echo ('<span class="are">Are you sure you want to delete a menu item with ID '. $_GET['deleteid'].
	'?</span><a  href="UpdateInventory.php?yesdelete='.$_GET['deleteid'].'"><div class="yes btn btn-lg btn-block btn-danger" >Yes</div></a>
	<a href="UpdateInventory.php"><div class="no btn btn-lg btn-block btn-success">No</div></a>');
	exit();  
}
if(isset($_GET['yesdelete'])) {
	//remove item from the database
	$itemid_todelete = $_GET['yesdelete'];
	$sql = "DELETE FROM Menu WHERE ItemId='$itemid_todelete' LIMIT 1";
	$con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
	$result = mysqli_query($con, $sql);
	header("location: UpdateInventory.php");

}
?>
</div>

<div class="manage">
<!--<?php include_once(""); //your website header template?>-->

<h1>Manage Inventory or <a href="logout.php">Log out</a></h1>
<hr />
<h3 align="right"><a href="Updateinventory.php#AddNewItem">+Add New Menu Item</a></h3>
<?php
$con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
$product_list="";

$sql= "SELECT * FROM Menu";
$result = mysqli_query($con, $sql);
$itemcount = mysqli_num_rows($result);
if ($itemcount>0) {
	while ($row = mysqli_fetch_array($result)) {
     	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
     	$category = $row["category"];
      	$product_list = "$itemid - $itemTitle - $itemDesc - $price - $category<a href='inventory_edit.php?itemid=$itemid'> &bull;Edit</a> &bull;
      			 <a href='UpdateInventory.php?deleteid=$itemid'>Delete</a><br />";
       	echo ($product_list);
 }
} else {
 echo ('No products to display');
  }
 
?>



<a name="AddNewItem" id="AddNewItem"></a>
<h2 align="center">Add New Menu Item</h2>
<form action="UpdateInventory.php" enctype="multipart/form-data" method="post">
<table width="90%" border="0" cellspacing="10" cellpadding="5">
<tr>
	<td width="20%">Menu Item Title</td>
	<td width="60%"><label><input name="ItemTitle" type="text" id="ItemTitle" size="30" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Description</td>
	<td><label><input name="ItemDesc" type="text" id="ItemDesc" size="80" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Price $</td>
	<td><label><input name="Price" type="text" id="Price" size="12" />
	</label></td>
</tr>
<tr>
	<td>Menu Item Category</td>
	<td><label><input name="category" type="text" id="category" size="20" />
	</label></td>
</tr>
<tr>
	<td>Product Image</td>
	<td><label><input name="fileField" type="file" id="fileField" />
	</label></td>
</tr>

<tr><td><!--<input type="submit" value="Add New Item" />-->
	
	</td>
	<td>
		
	</td>
	</tr>

</table>

<div class="row">
	<div class="col-xs-6"><button class="btn btn-lg btn-primary btn-block" type="submit">Add New Item</button></div>
	<div class="col-xs-6"><a class="btn btn-warning btn-lg btn-block" href="logout.php">Log out</a></div>
</div>

</form>

<?php  
if (isset($_POST['ItemTitle'])) {
	
	$title = trim($_POST['ItemTitle']);
	$desc = trim($_POST['ItemDesc']);
	$price = trim($_POST['Price']);
	$cat = trim($_POST['category']);
	
	//check if this title doesn't exist
	$sql= "SELECT ItemID FROM Menu where ItemTitle='$title' LIMIT 1";
	$result = mysqli_query($con, $sql);
	$itemcount = mysqli_num_rows($result);
	if ($itemcount>0) {
		echo ('<div class="itemExist"> this item already exist</div>
		<h3 align="right"><a href="Updateinventory.php#Click Here to continue">+Click Here to continue</a></h3>
		<!-- <a class="btn btn-lg btn-primary btn-block" type="submit" href="UpdateInventory.php">
		 Click Here to continue</a>-->');
		exit();
	}
	
	//Add this menu item to the Menu table
	$sql = "INSERT INTO Menu (ItemTitle, ItemDesc, Price, category) VALUES ('$title', '$desc', '$price', '$cat')";
	mysqli_query($con, $sql);
	$pid = mysqli_insert_id($con);
	echo('<div class="nmbr">'.$pid.'</div>');
	//Place image in the folder
	$newname = "$pid.jpg";
	move_uploaded_file( $_FILES['fileField']['tmp_name'], "images/$newname");
	
	//header("location: UpdateInventory.php");
	//exit();	
	}

?>

<!--<?php include_once(""); //your website footer template?>-->

</div>
</body></html>