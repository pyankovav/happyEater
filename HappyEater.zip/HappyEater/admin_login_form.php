<form method="post" action="admin_login_new.php" class="form-signin" >

<h2 class="form-signin-heading">Please login to manage the store or
<br> create a <a href="adminnewaccount.php">New Account</a></h2>
<hr />

<div class="enter">
  <label for="usr" class="sr-only">Username</label>
  <input type="text" name="usr" id="usr" class="form-control" placeholder="Username" required>
</div>
<div class="enter">
  <label for="pass" class="sr-only">Password</label>
  <input type="password" name="pass" id="pass" class="form-control" placeholder="Password" required>
</div>
 <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>

</form>
