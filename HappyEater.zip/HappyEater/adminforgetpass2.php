<?php
session_start();
?>

<?php
error_reporting(0);
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<html>
<head>
<title>Password Reset Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="adminforgetpass2.css">
</head>
<body>
<?php
	 $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');

			$password = trim($_POST['pwd']);
			$username = trim($_POST['user']);
			$query = "UPDATE admins SET password = '$password' WHERE username = '$username'";
			$result = mysqli_query($con, $query);
			$query1 = "SELECT username, password FROM admins WHERE username = '$username'";
			$result1 = mysqli_query($con, $query1);
			if (mysqli_num_rows($result1) == 1) {
				while ($row = mysqli_fetch_array($result1)) {
				$pass = $row["password"];
					if ($password == $pass){
						echo('<h2>Password Reset Successful</h2>
						<a class="btn btn-lg btn-primary btn-block" href="admin_login_new.php">Click here to login</a>');						
					}
					else {
						echo('<h3>Password Reset Unsuccessful!</h3><h3>
						<a href="adminforgetpass.php">Click here to reset it again</a></h3>');
					}
				}
			}
		
			
 ?>

</body></html>