
<!DOCTYPE html>
<html lang="en">
<head>
<title>New Account</title>

<!--
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"> -->

<meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
   <!-- <link rel="stylesheet" type="text/css" href="newaccount.css">-->
    <link rel="stylesheet" type="text/css" href="custom.css">
    
</head>

<body>

 <?php include_once("header_customer.php");?>
<div class="container custom_container">

<?php
 	// Connect to the database
       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');

			$username = trim($_POST['usr']);
      		$password = trim($_POST['pass']);
      		$first = trim($_POST['Fname']);
      		$last = trim($_POST['Lname']);
      		$email = trim($_POST['email']);
      		$address = trim($_POST['address']);
      		$zip = trim($_POST['zip']);
      		$phone = trim($_POST['phone']);
      		$comments = trim($_POST['comment']);
      		
      		
			if (!empty($username) && !empty($password) && !empty($email) && !empty($phone)) {
        	//Store username and password in the database
       		$query = "INSERT INTO CustInfo VALUES ('$username', '$password','$first', '$last', '$email', '$address', '$zip', '$phone', '$comments')";
       		
       		$result = mysqli_query($con, $query);
       		
			echo('<h2> Dear, ' . $first. ' . Your Account has been successfully created!</h2>
       <br><br>
       <a class="btn btn-lg btn-warning btn-block" href="index_customer.php">Click here for your happy shopping experience</a>');  
       		
       		$query1 = "SELECT username FROM CustInfo WHERE username = '$username' AND password = '$password'";
        	$result1 = mysqli_query($con, $query1);
       		if (mysqli_num_rows($result1) == 1) {
           
    		//echo('<h2>Login Successful!</h2><h3>You are logged in as ' . $username . '.</h3>');
       		
       		}
       	//	else {
       	//	echo('<p> All fields are required!.');
       //		}
       		}
       		else {
       		echo('<p> Sorry, you must enter a valid username and password to create account.<a href="orderonline.php">Create New Account</a>');
       		}


       		
?>

</div>
<?php include_once("footer_customer.php");?>
</body>
</html>


