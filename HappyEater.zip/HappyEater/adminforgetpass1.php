<?php
session_start();
?>

<?php
error_reporting(0);
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<html>
<head>
<title>Password Reset Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="adminforgetpass1.css">
</head>

<body>

<h2 class="form-signin-heading"> Confirm your password </h2>
<hr />
<?php
	 $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 	 $username = trim($_POST['user']);
   
	if (!empty($username)) {
		$query = "SELECT username FROM admins WHERE username = '$username'";
		$result = mysqli_query($con, $query);
		if (mysqli_num_rows($result) == 1) {
		 	echo('<form method="post" action="adminforgetpass2.php" class="form-signin">
			<div class="enter">
			<label for="inputPassword" class="sr-only">Enter New Password</label>
			<input type="password" name="pwd" class="form-control" placeholder="new password" required>
			</div>
			<div class="enter">
			<input type="hidden" name="user" value="'. $username.'">			
			</div>
			<button class="btn btn-lg btn-primary btn-block" type="submit">Confirm</button>
			</form>');
			
		}
		else {
       			echo('<p> Sorry, you must enter a valid username to reset your password.');
       		} 
	}
 ?>
</body>
</html>