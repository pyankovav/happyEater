<?php
session_start();
error_reporting(0);
if (!isset($_SESSION["manager"])) {
	header("location: admin_login_new.php");
	exit();
}
?>
<html>
<head>
<title>Admin Control Panel</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="adminhome.css">
</head>
<body>
<!--<?php //include_once("template_Header_members.php"); //your website header template?>
<br><br><br><br><br><br><br><br>-->
<h1>Administrative Panel</h1>
<hr />
<a class="btn btn-lg btn-block btn-warning" href="adminforgetpass.php">Reset Password</a>
<a class="btn btn-lg btn-block btn-danger" href="updateinventory.php">Manage Inventory</a>
<a class="btn btn-lg btn-block btn-primary" href="logout.php">Log out</a>
 
</body>
</html>