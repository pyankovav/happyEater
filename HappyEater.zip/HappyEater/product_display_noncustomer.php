<?php
session_start();
error_reporting(0);
if (isset($_SESSION["username"])) {
	header("location: product_display.php");
	exit();
}

?>
<?php
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>
<?php
//check if itemid is set or exist in the database
if(isset($_GET['itemid'])) {
	$prodid = $_GET['itemid'];
	//$prodid = preg_replace('#[^0-9]#i', , $_GET['itemid']);
	
	$con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 		$query = "SELECT * FROM Menu where ItemId='$prodid' LIMIT 1";
      	$result = mysqli_query($con, $query);
       	$itemcount = mysqli_num_rows($result);
       
     if ($itemcount>0) {
      while ($row = mysqli_fetch_array($result)) {
     	$itemid = $row["ItemID"];
     	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
    	$price = $row["Price"];
      	$cat = $row["category"];
       	    
     }	
   }
 } else { 
	echo('<div style="padding: 20px; font-size: 40px;
	 font-family: sans-serif; border: 2px solid #ccc; text-align: center; width: 50%; margin: 0 auto;"> no product to display</div>');
	exit();

mysql_close();
	

}

 
 ?>
<html>
<head>
<title> <?php echo $itemTitle; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
<link rel="stylesheet" type="text/css" href="product_display.css" / >
<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
 <?php include_once("header_noncustomer.php");?>
	<div class="container prod-img-page">	
		
		<div class="row">
			<div class="col-sm-6 text-center">
				<a class="view-full-size-img" data-toggle="modal" data-target=".bs-example-modal-lg" href="javascript:void(0);">
					<img class="img-responsive" src="images/<?php echo $itemid; ?>.jpg" >
		
					<i class="fa fa-search-plus"></i>
				</a>
			</div>
			<div class="col-sm-6"> 
				<h1><?php echo $itemTitle; ?></h1>	
			
				<div class="item_descr"><?php echo $itemDesc; ?></div><br />
				<div class="item_price">$<?php echo $price; ?></div><br />
				<div class="what_menu">From '<?php echo $cat; ?>' menu</div><br />			
				<a class="btn btn-default btn-lg" href="javascript:history.back();">Back to menu</a>
				
			</div>
		</div>
	
	</div>
	  <?php include_once("footer_customer.php");?>


<!-- Modal -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div modal-dialog>
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $itemTitle; ?></h4>
      </div>
      <div class="modal-body text-center">
        <img src="images/<?php echo $itemid; ?>.jpg" >
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



</body>
</html>