
<?php
session_start();
//if (!isset($_SESSION["username"])) {
//	header("location: index.php");
//	exit();
  
//}
?>
<?php
//Error Reporting
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
<link rel="stylesheet" type="text/css" href="OrderSelectionStyle.css">
<link rel="stylesheet" type="text/css" href="assets/css/custom.css">

<!--    <link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">-->

</head>
<body>

 <?php include_once("header_noncustomer.php");?>
 <div  class="container oderselection">
 <a name="nonbreakfast"></a><br><br><br>
<article>
<h1>Breakfast Menu </h1>
<div class= "table-responsive">
<table class = "table table-hover table-striped table-bordered ">
<?php

       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 		
 		$query = "SELECT * FROM Menu where category='Breakfast'";
       $result = mysqli_query($con, $query);
        
        $itemcount = mysqli_num_rows($result);
       
       if ($itemcount>0) {
        while ($row = mysqli_fetch_array($result)) {
       	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
        	
       		echo ('<tr><td>'. $itemid. '</td><td><a href="product_display_noncustomer.php?itemid='.$itemid. '">'. $itemTitle. '</a></td><td>'.$itemDesc. '</td>
       		<td>'. $price. '</td><td>');
       	  //echo ('<a href="Cart.php?id='.$itemid. '">Add to Cart</a> </td></tr>');
            echo ('<a href="Orderonline.php?id='.$itemid. '">Register to shop</a> </td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
 
 ?>
     </table>
      </div>
    </article>
<a name="nonlunch"></a><br><br><br>
<article>
    <h1>Lunch Menu </h1>
<div class= "table-responsive">
<table class="table table-hover table-striped table-bordered table-condensed">
<?php

       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 		
 		$query = "SELECT * FROM Menu where category='Lunch'";
       $result = mysqli_query($con, $query);
        
        $itemcount = mysqli_num_rows($result);
       
       if ($itemcount>0) {
        while ($row = mysqli_fetch_array($result)) {
       	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
        	
       		echo ('<tr><td>'. $itemid. '</td><td><a href="product_display_noncustomer.php?itemid='.$itemid. '">'. $itemTitle. '</td><td>'.$itemDesc. '</td>
       		<td>'. $price. '</td><td>');
       		//echo ('<a href="Cart.php?id='.$itemid. '">Add to Cart</a> </td></tr>');
          echo ('<a href="Orderonline.php?id='.$itemid. '">Register to shop</a> </td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
       
 ?> 	
    </table>
    </div>
</article>
<a name="nondinner"></a><br><br><br>
<article>
    <h1>Dinner Menu </h1>
   <div class= "table-responsive">
<table class="table table-hover table-striped table-bordered">
<?php

       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 		
 		$query = "SELECT * FROM Menu where category='Dinner'";
       $result = mysqli_query($con, $query);
        
        $itemcount = mysqli_num_rows($result);
       
       if ($itemcount>0) {
        while ($row = mysqli_fetch_array($result)) {
       	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
        	
       	echo ('<tr><td>'. $itemid. '</td><td><a href="product_display_noncustomer.php?itemid='.$itemid. '">'. $itemTitle. '</td><td>'.$itemDesc. '</td><td>'. $price. '</td><td>');
       	//echo ('<a href="Cart.php?id='.$itemid. '">Add to cart</a> </td></tr>');
        echo ('<a href="Orderonline.php?id='.$itemid. '">Register to shop</a> </td></tr>');
       }		
     } else {
     echo ('No products to display');
    }
       
 ?>
    </table>
    </div>
    </article>

<a name="nonallday"></a><br><br><br>
<article>
 <h1>All Day Menu </h1>
<div class= "table-responsive">
<table class = "table table-hover table-striped table-bordered ">
<?php

       $con = mysqli_connect ('localhost', 'root', '', 'Orders')
 		or die('Error connecting to MySQL server.');
 		
 		$query = "SELECT * FROM Menu where category='All Day'";
       $result = mysqli_query($con, $query);
        
        $itemcount = mysqli_num_rows($result);
       
       if ($itemcount>0) {
        while ($row = mysqli_fetch_array($result)) {
       	$itemid = $row["ItemID"];
       	$itemTitle = $row["ItemTitle"];
        $itemDesc = $row["ItemDesc"];
       	$price = $row["Price"];
        	
       		echo ('<tr><td>'. $itemid. '</td><td><a href="product_display_noncustomer.php?itemid='.$itemid. '">'. $itemTitle. '</a></td><td>'.$itemDesc. '</td>
       		<td>'. $price. '</td><td>');
       		//echo ('<a href="Cart.php?id='.$itemid. '">Add to Cart</a> </td></tr>');
          echo ('<a href="Orderonline.php?id='.$itemid. '">Register to shop</a> </td></tr>');
      	}
     } else {
     echo ('No products to display');
    }
 
 ?>

    </table>
    </div>
 	</article> 
  </div>
  <?php include_once("footer_customer.php");?>
    </body>
    </html>
    
  